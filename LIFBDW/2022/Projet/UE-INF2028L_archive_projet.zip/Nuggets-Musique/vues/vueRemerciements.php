
<head>
    <meta charset="utf-8" />
    <link href="css/style.css" rel="stylesheet" media="all" type="text/css">
</head>

<main>
	<center><h3>Remerciements</h3> </br></br>
		<div class="section-content">
			<div class ="gauche bloc"> 
				<div class="title-config">Déssin du Logo</div>
				<p class="Desc"> Merci à Louis Roussage pour la réalisation du logo,
					celui-ci représente la pochette de l'album "First Fly" réaliser
				par Virgile Broillet, vous pourez retrouvez celui-ci sur toutes les platformes, ainsi que sur <?php echo $nomSite; ?>. </p>
				<p class ="Desc"> <a href="https://linktr.ee/flyingnuggets" target="_blank" class="link"> Accéder à l'album First Fly</a></p>
			</div>
			<div class ="droite bloc right"> 
				<div class="title-config">Projet BDW</div>
				<p class="Desc"> Merci à l'Université Lyon 1, ainsi qu'a Fabien Duchateau pour la bonne réalisation de ce projet.
				Vous trouverez les liens vers la page de l'UE ainsi que vers la page de l'Université. </p>
				<p class ="Desc"> <a href="https://perso.liris.cnrs.fr/fabien.duchateau/" target="_blank" class="link"> Page de l'UE BDW</a></p>
				<p class ="Desc"> <a href="https://www.univ-lyon1.fr/" target="_blank" class="link"> Université Lyon 1</a></p>
			</div>
		</div>
	</center>
</main>