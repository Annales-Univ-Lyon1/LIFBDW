
<head>
    <meta charset="utf-8" />
    <link href="css/style.css" rel="stylesheet" media="all" type="text/css">
</head>

<main>
	<center>
		<h1>Alors comme ça on essaie de supprimer la BD ?</h1>
		<img src="img/test.gif"/>
	</center>
</main>