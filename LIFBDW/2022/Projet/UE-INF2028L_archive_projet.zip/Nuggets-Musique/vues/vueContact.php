
<head>
    <meta charset="utf-8" />
    <link href="css/style.css" rel="stylesheet" media="all" type="text/css">
</head>

<main>
	<center><h3>Contactez Nous</h3> </br></br>
		<div class="section-content">
			<div class ="gauche bloc"> 
				<div class="title-config">BROILLET Virgile (p2103804)</div>
				<p class="Desc"> Vous pouvez me contactez pour une quelconque information au <a href="tel:0659945420">06.59.94.54.20</a>. Ou encore m'envoyez un mail a cette adresse : </p>
				<p class ="Desc"> <a href="mailto:virgile.broillet@etu.univ-lyon1.fr">virgile.broillet@etu.univ-lyon1.fr</a></p>
				<p class="Desc"> Ou si vous souhaitez voir mes projets sur mon Github c'est ici que ça se passe ! </p>
				<p class ="Desc"> <a href="https://github.com/Virgile-Broillet" target="_blank">Virgile Broillet's Github</a></p>
			</div>
			<div class ="droite bloc right"> 
				<div class="title-config">ROUSSANGE Louis (p1904941)</div>
				<p class="Desc"> Envoyez-moi un mail a cette adresse si vous avez une question ! </p>
				<p class ="Desc"> <a href="mailto:louis.roussange@etu.univ-lyon1.fr">louis.roussange@etu.univ-lyon1.fr</a></p>
			</div>
		</div>
	</center>
</main>