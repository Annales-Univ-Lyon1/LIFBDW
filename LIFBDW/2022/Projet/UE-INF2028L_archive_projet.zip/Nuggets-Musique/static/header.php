<style> 
.texte{
	color:black;
}
.para {
	color:black;
	font-style: italic!important;
    text-align:center;
	display:block;    
	margin-block-start: 1em;    
	margin-block-end: 1em;    
	margin-inline-start: 0px;    
	margin-inline-end: 0px;
}
</style>

<div class="header">
	<div class="logo">	
		<a href="index.php">
			<img src="img/Logo_site.png" width="70%" height="70%">
		</a>
	</div>

    <div class="container_header">
        <h1 class="texte">Nuggets Musique</h1>
		<div class="para"><?= $baseline ?></div>
	</div>
</div>
