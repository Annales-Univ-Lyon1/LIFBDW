<head>
    <meta charset="utf-8" />
    <link href="css/style.css" rel="stylesheet" media="all" type="text/css">
</head>

<div class="vertical-menu">
    <a href="#" class="active"><a href="index.php">Accueil</a></a>
	<a href="index.php?page=afficher">Afficher</a>
    <a href="index.php?page=ajouter">Ajouter une Chanson</a>
    <a href="index.php?page=playlist">Ajouter/Supprimer Playlist</a>
    <a href="index.php?page=gerer">Gérer les Playlists</a>
    <a href="index.php?page=rechercher">Rechercher</a>

</div>

