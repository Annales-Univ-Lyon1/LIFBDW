<div class="footer">
	<div class="row">
		<ul>
			<li><a href="index.php?page=remerciements">Remerciements</a></li>
			<li><a href="index.php?page=contacts">Contactez Nous</a></li>
			<li><a href="https://perso.liris.cnrs.fr/fabien.duchateau/bdw" target="_blank">BDW - Base de données et programmation WEB</a></li>
			<li><a href="https://www.univ-lyon1.fr/" target="_blank">Université Lyon 1</a></li>
		</ul>
	</div>

	<div class="row">
		Copyright © <span><?php print date("Y"); ?> - <em><?= $nomSite ?></em></span> - All rights reserved
	</div>
</div>

